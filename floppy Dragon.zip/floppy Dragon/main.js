const canvas = document.getElementById("canvas");
const ctx = canvas.getContext('2d');

canvas.width = 400;
canvas.height = 550;

var bgWidth = 1920*(550/1080);
var bgHeight = 1080*(550/1080);
var pillarWidth = 80/1.5;
var pillarHeight = 400/1.5;

var score = 0;

var bgSkyX = 0;
var bgHillX = 0;
var bgSiliconX = 0;
var bgFloorX = 0;
//var bgCattasX = 0;
var bgY = 0;


pillarX = 200;
pillarY = 0;
 //the with and height of our spritesheet
 var spriteWidth = 573; 
 var spriteHeight = 644; 
 //we are having two rows and 8 cols in the current sprite sheet
 var rows = 4; 
 var cols = 3; 
 //because all the sprites are of equal width and height 
 var width = spriteWidth/cols; 
 //Same for the height we divided the height with number of rows 
 var height = spriteHeight/rows;  
 //Each row contains 8 frame and at start we will display the first frame (assuming the index from 0)
 var curFrame = 0;  
 //The total frame is 8 
 var frameCount = 3;  
 //x and y coordinates to render the sprite 
 var x=50;
 var y=innerHeight/2; 
 //x and y coordinates of the canvas to get the single frame 
 var srcX=0; 
 var srcY=166; 
 //Speed of the movement 
 var speed = 1; 
 

let bgH = 550/980



function updateFrame(){
 //Updating the frame index 
 curFrame = ++curFrame % frameCount; 
 //Calculating the x coordinate for spritesheet 
 srcX = curFrame * width; 
}
addEventListener('touchstart',function playerUp (){
	if(y > 15){
		y-=40;
	}
});

function updatePlayer (){
	if(y < innerHeight-125){
		y+=.1;
	}
	

}


var bgSky = new Image();
var bgHill = new Image();
var bgSilicon = new Image();
var upPillar = new Image();
var downPillar = new Image();
var bgFloor = new Image();



bgSky.src = 'assets/1.png'
bgHill.src = 'assets/2.png'
bgSilicon.src = 'assets/3.png'
upPillar.src = 'assets/upPillar.png'
downPillar.src = 'assets/downPillar.png'
bgFloor.src = 'assets/5.png'

let rand = null;
let rand2 = null;




function bgAni(){
	bgHillX-=.1;
	if(bgHillX<0-bgWidth){
		bgHillX=bgHillX+bgWidth;
	}
	bgSiliconX-=.3;
	if(bgSiliconX < 0-bgWidth){
		bgSiliconX = bgSiliconX+bgWidth;
	}
	
	pillarX-=.2;
	if(pillarX<0-pillarWidth){
		pillarX=pillarX+400;
		rand = Math.ceil(Math.random()*(150-30)+30)
	}
	
	bgFloorX-=.5;
	if(bgFloorX<0-bgWidth){
		bgFloorX=bgFloorX+bgWidth;
	}
	
	ctx.drawImage(bgSky,bgSkyX,bgY,bgWidth,bgHeight);
	ctx.drawImage(bgSky,bgSkyX+bgWidth,bgY,bgWidth,bgHeight);
	
	ctx.drawImage(bgHill,bgHillX,bgY,bgWidth,bgHeight);
	ctx.drawImage(bgHill,bgHillX+bgWidth,bgY,bgWidth,bgHeight);

	ctx.drawImage(bgSilicon,bgSiliconX,bgY,bgWidth,bgHeight);
	ctx.drawImage(bgSilicon,bgSiliconX+bgWidth,bgY,bgWidth,bgHeight);
	
	ctx.drawImage(upPillar,pillarX,bgY-rand,pillarWidth,pillarHeight);
	ctx.drawImage(downPillar,pillarX,bgY-rand+pillarHeight+200,pillarWidth,pillarHeight)
	
	ctx.drawImage(bgFloor,bgFloorX,bgY,bgWidth,bgHeight);
	ctx.drawImage(bgFloor,bgFloorX+bgWidth,bgY,bgWidth,bgHeight);
	
	
	
	//COLLUTION DETECTION...........

	if(	(pillarX <= (x+width/2)-15 && y+15 <= gY-rand+pillarHeight && pillarX+pillarWidth <= x) || 
	(pillarX < (x+width/2)-10 && (y+height/2)-15 >= bgY-rand+pillarHeight+200)){
		cancelAnimationFrame (animation);
	}
	
}











let animation;
function draw(){
	animation = requestAnimationFrame(draw)
	ctx.clearRect (0,0,innerWidth,innerHeight)
	bgAni ()
	var player = new Image();
	player.src = "assets/player.png";
	updatePlayer();
	//Updating the frame 
	updateFrame();
	//Drawing the image 
	ctx.drawImage(player,srcX,srcY,width,height,x,y,width/2,height/2);
	
	document.getElementById('score').innerHTML= score;

	
}

setInterval(draw,10)